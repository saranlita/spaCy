## Examples of NER/IOB data that can be converted with `spacy convert`

spacy JSON training files were generated with:

```
python -m spacy convert -c iob -s -n 10 -b en file.iob
```
